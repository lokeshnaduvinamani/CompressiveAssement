package com.midtree.doctorpatient.exception;

public class DoctorNotFoundException  extends RuntimeException{

    public DoctorNotFoundException(String string) {
        super();
    }
}
