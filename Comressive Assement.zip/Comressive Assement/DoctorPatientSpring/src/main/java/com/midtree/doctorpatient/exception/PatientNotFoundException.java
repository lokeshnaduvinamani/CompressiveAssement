package com.midtree.doctorpatient.exception;

public class PatientNotFoundException  extends RuntimeException{
    public PatientNotFoundException(String string) {
        super();
    }
}
