package com.midtree.doctorpatient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitaldetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitaldetailsApplication.class, args);
	}

}
