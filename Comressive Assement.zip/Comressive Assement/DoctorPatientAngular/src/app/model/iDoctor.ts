export interface IDoctor{
    id:number;
    name:string;
    field:string;
    age?:number;
    gender?:string;
    patient_count?:number;
}